package com.aurionpro.model;

public enum MarkType {
	EMPTY, X, O;
	

}
