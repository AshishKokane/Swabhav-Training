package com.aurionpro.model;

public class cellAlreadyMarkedException extends RuntimeException {

	public cellAlreadyMarkedException(String string) {
		super(string);
	}

}
