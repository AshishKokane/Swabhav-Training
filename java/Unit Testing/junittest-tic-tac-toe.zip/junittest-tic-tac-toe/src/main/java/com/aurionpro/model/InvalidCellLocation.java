package com.aurionpro.model;

public class InvalidCellLocation extends Exception {
	
	public InvalidCellLocation(String message) {
		super(message);
	}


}
